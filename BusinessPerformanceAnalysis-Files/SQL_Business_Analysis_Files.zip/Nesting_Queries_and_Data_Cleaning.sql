/*
CREATED BY: Jonathan Sebastiani
CREATED DATE: 10/14/2025
DESCRIPTION: Define the music tracks that have not have any sales.

Notes:
The DISTINCT clause returns only unique values for that field
*/

SELECT
	TrackId,
	Name,
	Composer
FROM
	Track
WHERE
TrackId NOT IN
	(SELECT
		DISTINCT TrackId
	FROM	
		InvoiceLine)
