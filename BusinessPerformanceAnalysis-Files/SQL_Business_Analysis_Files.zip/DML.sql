/*
CREATED BY: Jonathan Sebastiani
CREATED DATE: 10/14/2025
DESCRIPTION: Adding, changing, or deleting data from a database
	DML (Data Manipulation Language)
		- INSERT
		- UPDATE
		- DELETE

Notes:
	Be careful not to accidently update or delete everything and lose data 
*/

-- Add an additional artist into the database 
INSERT INTO
	Artist(name) -- The table and field that you want to insert into
VALUES('Bob Marley')

-- Update data
UPDATE 
	Artist
Name = 'Damion Marley'
WHERE
	ArtistId = 276
	
-- Delete data 
DELETE FROM
	Artist
WHERE
	ArtistId = 276
