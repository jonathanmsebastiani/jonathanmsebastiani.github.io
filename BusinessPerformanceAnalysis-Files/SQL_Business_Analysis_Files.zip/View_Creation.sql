/*
CREATED BY: Jonathan Sebastiani
CREATED DATE: 10/14/2025
DESCRIPTION: Creat a view with the running global average for sales

Notes:
The DISTINCT clause returns only unique values for that field
*/

CREATE VIEW V_GlobalAverage AS 
	SELECT
		AVG(total) as 'Global Average'
	FROM
		Invoice
